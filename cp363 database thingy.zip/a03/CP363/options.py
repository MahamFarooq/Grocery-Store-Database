
#Collection of all the code for A9 written by 

#Query Tables
print("""hello world
h

hh

h""")
